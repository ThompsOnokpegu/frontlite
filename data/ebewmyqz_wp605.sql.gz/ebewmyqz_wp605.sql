-- MySQL dump 10.18  Distrib 10.3.27-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: ebewmyqz_wp605
-- ------------------------------------------------------
-- Server version	10.3.27-MariaDB-log-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `wpaa_commentmeta`
--

DROP TABLE IF EXISTS `wpaa_commentmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wpaa_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wpaa_commentmeta`
--

LOCK TABLES `wpaa_commentmeta` WRITE;
/*!40000 ALTER TABLE `wpaa_commentmeta` DISABLE KEYS */;
/*!40000 ALTER TABLE `wpaa_commentmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wpaa_comments`
--

DROP TABLE IF EXISTS `wpaa_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wpaa_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT 0,
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wpaa_comments`
--

LOCK TABLES `wpaa_comments` WRITE;
/*!40000 ALTER TABLE `wpaa_comments` DISABLE KEYS */;
INSERT INTO `wpaa_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES (1,1,'A WordPress Commenter','wapuu@wordpress.example','https://wordpress.org/','','2020-01-29 08:25:03','2020-01-29 08:25:03','Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://gravatar.com\">Gravatar</a>.',0,'1','','',0,0);
/*!40000 ALTER TABLE `wpaa_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wpaa_links`
--

DROP TABLE IF EXISTS `wpaa_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wpaa_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT 1,
  `link_rating` int(11) NOT NULL DEFAULT 0,
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wpaa_links`
--

LOCK TABLES `wpaa_links` WRITE;
/*!40000 ALTER TABLE `wpaa_links` DISABLE KEYS */;
/*!40000 ALTER TABLE `wpaa_links` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wpaa_loginizer_logs`
--

DROP TABLE IF EXISTS `wpaa_loginizer_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wpaa_loginizer_logs` (
  `username` varchar(255) NOT NULL DEFAULT '',
  `time` int(10) NOT NULL DEFAULT 0,
  `count` int(10) NOT NULL DEFAULT 0,
  `lockout` int(10) NOT NULL DEFAULT 0,
  `ip` varchar(255) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  UNIQUE KEY `ip` (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wpaa_loginizer_logs`
--

LOCK TABLES `wpaa_loginizer_logs` WRITE;
/*!40000 ALTER TABLE `wpaa_loginizer_logs` DISABLE KEYS */;
/*!40000 ALTER TABLE `wpaa_loginizer_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wpaa_options`
--

DROP TABLE IF EXISTS `wpaa_options`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wpaa_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=MyISAM AUTO_INCREMENT=2641 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wpaa_options`
--

LOCK TABLES `wpaa_options` WRITE;
/*!40000 ALTER TABLE `wpaa_options` DISABLE KEYS */;
INSERT INTO `wpaa_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES (1,'siteurl','http://stagging.ebewelebrown.com','yes'),(2,'home','http://stagging.ebewelebrown.com','yes'),(3,'blogname','Ebewele Brown','yes'),(4,'blogdescription','Bespoke Tailoring','yes'),(5,'users_can_register','0','yes'),(6,'admin_email','tommyriode@gmail.com','yes'),(7,'start_of_week','1','yes'),(8,'use_balanceTags','0','yes'),(9,'use_smilies','1','yes'),(10,'require_name_email','1','yes'),(11,'comments_notify','1','yes'),(12,'posts_per_rss','10','yes'),(13,'rss_use_excerpt','0','yes'),(14,'mailserver_url','mail.example.com','yes'),(15,'mailserver_login','login@example.com','yes'),(16,'mailserver_pass','password','yes'),(17,'mailserver_port','110','yes'),(18,'default_category','1','yes'),(19,'default_comment_status','open','yes'),(20,'default_ping_status','open','yes'),(21,'default_pingback_flag','1','yes'),(22,'posts_per_page','10','yes'),(23,'date_format','F j, Y','yes'),(24,'time_format','g:i a','yes'),(25,'links_updated_date_format','F j, Y g:i a','yes'),(26,'comment_moderation','0','yes'),(27,'moderation_notify','1','yes'),(28,'permalink_structure','','yes'),(29,'rewrite_rules','','yes'),(30,'hack_file','0','yes'),(31,'blog_charset','UTF-8','yes'),(32,'moderation_keys','','no'),(33,'active_plugins','a:2:{i:0;s:35:\"litespeed-cache/litespeed-cache.php\";i:1;s:23:\"loginizer/loginizer.php\";}','yes'),(34,'category_base','','yes'),(35,'ping_sites','http://rpc.pingomatic.com/','yes'),(36,'comment_max_links','2','yes'),(37,'gmt_offset','0','yes'),(38,'default_email_category','1','yes'),(39,'recently_edited','','no'),(40,'template','twentytwenty','yes'),(41,'stylesheet','twentytwenty','yes'),(2494,'finished_updating_comment_type','0','yes'),(44,'comment_registration','0','yes'),(45,'html_type','text/html','yes'),(46,'use_trackback','0','yes'),(47,'default_role','subscriber','yes'),(48,'db_version','49752','yes'),(49,'uploads_use_yearmonth_folders','1','yes'),(50,'upload_path','','yes'),(51,'blog_public','1','yes'),(52,'default_link_category','2','yes'),(53,'show_on_front','posts','yes'),(54,'tag_base','','yes'),(55,'show_avatars','1','yes'),(56,'avatar_rating','G','yes'),(57,'upload_url_path','','yes'),(58,'thumbnail_size_w','150','yes'),(59,'thumbnail_size_h','150','yes'),(60,'thumbnail_crop','1','yes'),(61,'medium_size_w','300','yes'),(62,'medium_size_h','300','yes'),(63,'avatar_default','mystery','yes'),(64,'large_size_w','1024','yes'),(65,'large_size_h','1024','yes'),(66,'image_default_link_type','none','yes'),(67,'image_default_size','','yes'),(68,'image_default_align','','yes'),(69,'close_comments_for_old_posts','0','yes'),(70,'close_comments_days_old','14','yes'),(71,'thread_comments','1','yes'),(72,'thread_comments_depth','5','yes'),(73,'page_comments','0','yes'),(74,'comments_per_page','50','yes'),(75,'default_comments_page','newest','yes'),(76,'comment_order','asc','yes'),(77,'sticky_posts','a:0:{}','yes'),(78,'widget_categories','a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}','yes'),(79,'widget_text','a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}','yes'),(80,'widget_rss','a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}','yes'),(81,'uninstall_plugins','a:2:{s:35:\"litespeed-cache/litespeed-cache.php\";s:47:\"LiteSpeed\\Activation::uninstall_litespeed_cache\";s:23:\"loginizer/loginizer.php\";s:22:\"loginizer_deactivation\";}','no'),(82,'timezone_string','','yes'),(83,'page_for_posts','0','yes'),(84,'page_on_front','0','yes'),(85,'default_post_format','0','yes'),(86,'link_manager_enabled','0','yes'),(87,'finished_splitting_shared_terms','1','yes'),(88,'site_icon','0','yes'),(89,'medium_large_size_w','768','yes'),(90,'medium_large_size_h','0','yes'),(91,'wp_page_for_privacy_policy','3','yes'),(92,'show_comments_cookies_opt_in','1','yes'),(93,'admin_email_lifespan','1595838303','yes'),(94,'initial_db_version','45805','yes'),(95,'wpaa_user_roles','a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}','yes'),(96,'fresh_site','1','yes'),(97,'widget_search','a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}','yes'),(98,'widget_recent-posts','a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}','yes'),(99,'widget_recent-comments','a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}','yes'),(100,'widget_archives','a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}','yes'),(101,'widget_meta','a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}','yes'),(102,'sidebars_widgets','a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:3:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";}s:9:\"sidebar-2\";a:3:{i:0;s:10:\"archives-2\";i:1;s:12:\"categories-2\";i:2;s:6:\"meta-2\";}s:13:\"array_version\";i:3;}','yes'),(103,'cron','a:7:{i:1609929016;a:3:{s:27:\"litespeed_task_imgoptm_pull\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:16:\"litespeed_filter\";s:4:\"args\";a:0:{}s:8:\"interval\";i:60;}}s:19:\"litespeed_task_ccss\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:16:\"litespeed_filter\";s:4:\"args\";a:0:{}s:8:\"interval\";i:60;}}s:19:\"litespeed_task_lqip\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:16:\"litespeed_filter\";s:4:\"args\";a:0:{}s:8:\"interval\";i:60;}}}i:1609929774;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1609951490;a:3:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1609964703;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1610007903;a:1:{s:32:\"recovery_mode_clean_expired_keys\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1610019080;a:1:{s:30:\"wp_site_health_scheduled_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"weekly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:604800;}}}s:7:\"version\";i:2;}','yes'),(104,'widget_pages','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(105,'widget_calendar','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(106,'widget_media_audio','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(107,'widget_media_image','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(108,'widget_media_gallery','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(109,'widget_media_video','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(110,'widget_tag_cloud','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(111,'widget_nav_menu','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(112,'widget_custom_html','a:1:{s:12:\"_multiwidget\";i:1;}','yes'),(113,'recovery_keys','a:0:{}','yes'),(114,'theme_mods_twentytwenty','a:1:{s:18:\"custom_css_post_id\";i:-1;}','yes'),(1769,'litespeed.conf.cache-priv','1','yes'),(1770,'litespeed.conf.cache-commenter','1','yes'),(1771,'litespeed.conf.cache-rest','1','yes'),(1772,'litespeed.conf.cache-page_login','1','yes'),(1773,'litespeed.conf.cache-favicon','1','yes'),(1774,'litespeed.conf.cache-resources','1','yes'),(1775,'litespeed.conf.cache-mobile','','yes'),(1776,'litespeed.conf.cache-mobile_rules','a:7:{i:0;s:6:\"Mobile\";i:1;s:7:\"Android\";i:2;s:5:\"Silk/\";i:3;s:6:\"Kindle\";i:4;s:10:\"BlackBerry\";i:5;s:10:\"Opera Mini\";i:6;s:10:\"Opera Mobi\";}','yes'),(1777,'litespeed.conf.cache-browser','','yes'),(139,'_transient_timeout_feed_9bbd59226dc36b9b26cd43f15694c5c3','1580877929','no'),(1826,'litespeed.conf.debug-collaps_qs','','yes'),(1827,'litespeed.conf.debug-inc','a:0:{}','yes'),(1828,'litespeed.conf.debug-exc','a:0:{}','yes'),(1761,'litespeed.cloud._summary','a:2:{s:19:\"curr_request.wp/ver\";i:0;s:19:\"last_request.wp/ver\";i:1604504206;}','yes'),(1762,'litespeed.conf._version','3.4.2','yes'),(1763,'litespeed.conf.hash','Mdzu6Utnbgbt54W7sQkmD47S30ek7l7M','yes'),(1764,'litespeed.conf.auto_upgrade','','yes'),(1765,'litespeed.conf.api_key','','yes'),(1766,'litespeed.conf.server_ip','','yes'),(1767,'litespeed.conf.news','1','yes'),(1768,'litespeed.conf.cache','1','yes'),(142,'_transient_timeout_feed_d117b5738fbd35bd8c0391cda1f2b5d9','1580877930','no'),(1884,'litespeed.conf.object-non_persistent_groups','a:4:{i:0;s:7:\"comment\";i:1;s:6:\"counts\";i:2;s:7:\"plugins\";i:3;s:13:\"wc_session_id\";}','yes'),(1872,'litespeed.conf.object','','yes'),(1873,'litespeed.conf.object-kind','','yes'),(1874,'litespeed.conf.object-host','localhost','yes'),(1875,'litespeed.conf.object-port','11211','yes'),(1876,'litespeed.conf.object-life','360','yes'),(1877,'litespeed.conf.object-persistent','1','yes'),(1878,'litespeed.conf.object-admin','1','yes'),(1879,'litespeed.conf.object-transients','1','yes'),(1880,'litespeed.conf.object-db_id','0','yes'),(1881,'litespeed.conf.object-user','','yes'),(1882,'litespeed.conf.object-pswd','','yes'),(1883,'litespeed.conf.object-global_groups','a:12:{i:0;s:5:\"users\";i:1;s:10:\"userlogins\";i:2;s:8:\"usermeta\";i:3;s:9:\"user_meta\";i:4;s:14:\"site-transient\";i:5;s:12:\"site-options\";i:6;s:11:\"site-lookup\";i:7;s:11:\"blog-lookup\";i:8;s:12:\"blog-details\";i:9;s:3:\"rss\";i:10;s:12:\"global-posts\";i:11;s:13:\"blog-id-cache\";}','yes'),(1868,'litespeed.conf.optm-dns_prefetch_ctrl','','yes'),(1869,'litespeed.conf.optm-exc','a:0:{}','yes'),(1870,'litespeed.conf.optm-ccss_sep_posttype','a:0:{}','yes'),(1871,'litespeed.conf.optm-ccss_sep_uri','a:0:{}','yes'),(149,'theme_mods_twentysixteen','a:1:{s:18:\"custom_css_post_id\";i:-1;}','yes'),(150,'_transient_is_multi_author','0','yes'),(151,'_transient_twentysixteen_categories','1','yes'),(1865,'litespeed.conf.optm-js_defer_exc','a:0:{}','yes'),(1866,'litespeed.conf.optm-js_inline_defer_exc','a:0:{}','yes'),(1867,'litespeed.conf.optm-dns_prefetch','a:0:{}','yes'),(1862,'litespeed.conf.optm-rm_comment','','yes'),(1863,'litespeed.conf.optm-exc_roles','a:0:{}','yes'),(1864,'litespeed.conf.optm-ccss_con','','yes'),(1859,'litespeed.conf.optm-exc_jq','1','yes'),(1860,'litespeed.conf.optm-ggfonts_async','','yes'),(1861,'litespeed.conf.optm-max_size','2','yes'),(1856,'litespeed.conf.optm-js_inline_defer','','yes'),(1857,'litespeed.conf.optm-emoji_rm','','yes'),(1858,'litespeed.conf.optm-noscript_rm','','yes'),(1853,'litespeed.conf.optm-css_async_inline','1','yes'),(1854,'litespeed.conf.optm-css_font_display','','yes'),(1855,'litespeed.conf.optm-js_defer','','yes'),(1849,'litespeed.conf.optm-ggfonts_rm','','yes'),(1850,'litespeed.conf.optm-css_async','','yes'),(1851,'litespeed.conf.optm-ccss_gen','1','yes'),(1852,'litespeed.conf.optm-ccss_async','1','yes'),(1846,'litespeed.conf.optm-ttl','604800','yes'),(1847,'litespeed.conf.optm-html_min','','yes'),(1848,'litespeed.conf.optm-qs_rm','','yes'),(1842,'litespeed.conf.optm-js_comb','','yes'),(1843,'litespeed.conf.optm-js_comb_priority','','yes'),(1844,'litespeed.conf.optm-js_http2','','yes'),(1845,'litespeed.conf.optm-js_exc','a:0:{}','yes'),(1839,'litespeed.conf.optm-css_exc','a:0:{}','yes'),(1840,'litespeed.conf.optm-js_min','','yes'),(1841,'litespeed.conf.optm-js_inline_min','','yes'),(1835,'litespeed.conf.optm-css_unique','','yes'),(1836,'litespeed.conf.optm-ucss','','yes'),(1837,'litespeed.conf.optm-ucss_async','','yes'),(1838,'litespeed.conf.optm-css_http2','','yes'),(1832,'litespeed.conf.optm-css_inline_min','','yes'),(1833,'litespeed.conf.optm-css_comb','','yes'),(1834,'litespeed.conf.optm-css_comb_priority','','yes'),(1824,'litespeed.conf.debug-filesize','3','yes'),(1825,'litespeed.conf.debug-cookie','','yes'),(1784,'litespeed.conf.cache-force_pub_uri','a:0:{}','yes'),(1785,'litespeed.conf.cache-priv_uri','a:0:{}','yes'),(1786,'litespeed.conf.cache-exc','a:0:{}','yes'),(1787,'litespeed.conf.cache-exc_roles','a:0:{}','yes'),(1788,'litespeed.conf.cache-drop_qs','a:4:{i:0;s:6:\"fbclid\";i:1;s:5:\"gclid\";i:2;s:4:\"utm*\";i:3;s:3:\"_ga\";}','yes'),(1789,'litespeed.conf.cache-ttl_pub','604800','yes'),(1790,'litespeed.conf.cache-ttl_priv','1800','yes'),(1791,'litespeed.conf.cache-ttl_frontpage','604800','yes'),(1792,'litespeed.conf.cache-ttl_feed','604800','yes'),(1793,'litespeed.conf.cache-ttl_rest','604800','yes'),(580,'auto_core_update_notified','a:4:{s:4:\"type\";s:7:\"success\";s:5:\"email\";s:20:\"tommyriode@gmail.com\";s:7:\"version\";s:5:\"5.3.6\";s:9:\"timestamp\";i:1604111203;}','no'),(1829,'litespeed.conf.db_optm-revisions_max','0','yes'),(1830,'litespeed.conf.db_optm-revisions_age','0','yes'),(1831,'litespeed.conf.optm-css_min','','yes'),(1821,'litespeed.conf.debug','','yes'),(1822,'litespeed.conf.debug-ips','a:1:{i:0;s:9:\"127.0.0.1\";}','yes'),(1823,'litespeed.conf.debug-level','','yes'),(1818,'litespeed.conf.util-instant_click','','yes'),(1819,'litespeed.conf.util-no_https_vary','','yes'),(1820,'litespeed.conf.debug-disable_all','','yes'),(1815,'litespeed.conf.esi-cache_admbar','1','yes'),(1816,'litespeed.conf.esi-cache_commform','1','yes'),(1817,'litespeed.conf.esi-nonce','a:2:{i:0;s:11:\"stats_nonce\";i:1;s:15:\"subscribe_nonce\";}','yes'),(1814,'litespeed.conf.esi','','yes'),(1812,'litespeed.conf.purge-timed_urls_time','','yes'),(1813,'litespeed.conf.purge-hook_all','a:10:{i:0;s:12:\"switch_theme\";i:1;s:18:\"wp_create_nav_menu\";i:2;s:18:\"wp_update_nav_menu\";i:3;s:18:\"wp_delete_nav_menu\";i:4;s:11:\"create_term\";i:5;s:10:\"edit_terms\";i:6;s:11:\"delete_term\";i:7;s:8:\"add_link\";i:8;s:9:\"edit_link\";i:9;s:11:\"delete_link\";}','yes'),(1809,'litespeed.conf.purge-post_t','1','yes'),(1810,'litespeed.conf.purge-post_pt','1','yes'),(1811,'litespeed.conf.purge-timed_urls','a:0:{}','yes'),(1806,'litespeed.conf.purge-post_y','','yes'),(1807,'litespeed.conf.purge-post_m','1','yes'),(1808,'litespeed.conf.purge-post_d','','yes'),(1803,'litespeed.conf.purge-post_p','1','yes'),(1804,'litespeed.conf.purge-post_pwrp','1','yes'),(1805,'litespeed.conf.purge-post_a','1','yes'),(1799,'litespeed.conf.purge-stale','','yes'),(1800,'litespeed.conf.purge-post_all','','yes'),(1801,'litespeed.conf.purge-post_f','1','yes'),(1802,'litespeed.conf.purge-post_h','1','yes'),(1796,'litespeed.conf.cache-login_cookie','','yes'),(1797,'litespeed.conf.cache-vary_group','a:0:{}','yes'),(1798,'litespeed.conf.purge-upgrade','1','yes'),(1794,'litespeed.conf.cache-ttl_browser','31557600','yes'),(1795,'litespeed.conf.cache-ttl_status','a:3:{i:0;s:8:\"403 3600\";i:1;s:8:\"404 3600\";i:2;s:8:\"500 3600\";}','yes'),(1778,'litespeed.conf.cache-exc_useragents','a:0:{}','yes'),(1779,'litespeed.conf.cache-exc_cookies','a:0:{}','yes'),(1780,'litespeed.conf.cache-exc_qs','a:0:{}','yes'),(1781,'litespeed.conf.cache-exc_cat','a:0:{}','yes'),(1782,'litespeed.conf.cache-exc_tag','a:0:{}','yes'),(1783,'litespeed.conf.cache-force_uri','a:0:{}','yes'),(2487,'disallowed_keys','','no'),(2488,'comment_previously_approved','1','yes'),(2489,'auto_plugin_theme_update_emails','a:0:{}','no'),(2490,'auto_update_core_dev','enabled','yes'),(2491,'auto_update_core_minor','enabled','yes'),(2492,'auto_update_core_major','unset','yes'),(1885,'litespeed.conf.discuss-avatar_cache','','yes'),(1886,'litespeed.conf.discuss-avatar_cron','','yes'),(1887,'litespeed.conf.discuss-avatar_cache_ttl','604800','yes'),(1888,'litespeed.conf.optm-localize','','yes'),(1889,'litespeed.conf.optm-localize_domains','a:35:{i:0;s:13:\"### some CDNs\";i:1;s:26:\"https://ajax.aspnetcdn.com\";i:2;s:28:\"https://ajax.cloudflare.com/\";i:3;s:33:\"https://ajax.googleapis.com/ajax/\";i:4;s:25:\"https://cdn.jsdelivr.net/\";i:5;s:18:\"https://cdnjs.com/\";i:6;s:29:\"https://cdnjs.cloudflare.com/\";i:7;s:24:\"https://code.jquery.com/\";i:8;s:32:\"https://maxcdn.bootstrapcdn.com/\";i:9;s:32:\"https://netdna.bootstrapcdn.com/\";i:10;s:23:\"https://oss.maxcdn.com/\";i:11;s:35:\"https://stackpath.bootstrapcdn.com/\";i:12;s:23:\"### Popular scripts ###\";i:13;s:30:\"https://a.optmnstr.com/app/js/\";i:14;s:31:\"https://cdn.onesignal.com/sdks/\";i:15;s:27:\"https://cdn.optimizely.com/\";i:16;s:26:\"https://cdn.shopify.com/s/\";i:17;s:48:\"https://css3-mediaqueries-js.googlecode.com/svn/\";i:18;s:37:\"https://html5shim.googlecode.com/svn/\";i:19;s:37:\"https://html5shiv.googlecode.com/svn/\";i:20;s:35:\"https://maps.google.com/maps/api/js\";i:21;s:39:\"https://maps.googleapis.com/maps/api/js\";i:22;s:48:\"https://pagead2.googlesyndication.com/pagead/js/\";i:23;s:39:\"https://platform.twitter.com/widgets.js\";i:24;s:38:\"https://platform-api.sharethis.com/js/\";i:25;s:26:\"https://s7.addthis.com/js/\";i:26;s:21:\"https://stats.wp.com/\";i:27;s:32:\"https://ws.sharethis.com/button/\";i:28;s:39:\"https://www.google.com/recaptcha/api.js\";i:29;s:45:\"https://www.google-analytics.com/analytics.js\";i:30;s:40:\"https://www.googletagmanager.com/gtag/js\";i:31;s:39:\"https://www.googletagmanager.com/gtm.js\";i:32;s:47:\"https://www.googletagservices.com/tag/js/gpt.js\";i:33;s:46:\"https://connect.facebook.net/en_US/fbevents.js\";i:34;s:44:\"https://connect.facebook.net/signals/config/\";}','yes'),(1890,'litespeed.conf.media-lazy','','yes'),(1891,'litespeed.conf.media-lazy_placeholder','','yes'),(1892,'litespeed.conf.media-placeholder_resp','','yes'),(1893,'litespeed.conf.media-placeholder_resp_color','#cfd4db','yes'),(1894,'litespeed.conf.media-placeholder_resp_svg','<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"{width}\" height=\"{height}\" viewBox=\"0 0 {width} {height}\"><rect width=\"100%\" height=\"100%\" fill=\"{color}\"/></svg>','yes'),(1895,'litespeed.conf.media-lqip','','yes'),(1896,'litespeed.conf.media-lqip_qual','4','yes'),(1897,'litespeed.conf.media-lqip_min_w','150','yes'),(1898,'litespeed.conf.media-lqip_min_h','150','yes'),(1899,'litespeed.conf.media-placeholder_resp_async','1','yes'),(1900,'litespeed.conf.media-iframe_lazy','','yes'),(1901,'litespeed.conf.media-lazyjs_inline','','yes'),(1902,'litespeed.conf.media-lazy_exc','a:0:{}','yes'),(1903,'litespeed.conf.media-lazy_cls_exc','a:1:{i:0;s:15:\"wmu-preview-img\";}','yes'),(1904,'litespeed.conf.media-lazy_parent_cls_exc','a:0:{}','yes'),(1905,'litespeed.conf.media-iframe_lazy_cls_exc','a:0:{}','yes'),(1906,'litespeed.conf.media-iframe_lazy_parent_cls_exc','a:0:{}','yes'),(1907,'litespeed.conf.media-lazy_uri_exc','a:0:{}','yes'),(1908,'litespeed.conf.media-lqip_exc','a:0:{}','yes'),(1909,'litespeed.conf.img_optm-auto','','yes'),(1910,'litespeed.conf.img_optm-cron','1','yes'),(1911,'litespeed.conf.img_optm-ori','1','yes'),(1912,'litespeed.conf.img_optm-rm_bkup','','yes'),(1913,'litespeed.conf.img_optm-webp','','yes'),(1914,'litespeed.conf.img_optm-lossless','','yes'),(1915,'litespeed.conf.img_optm-exif','','yes'),(1916,'litespeed.conf.img_optm-webp_replace','','yes'),(1917,'litespeed.conf.img_optm-webp_attr','a:7:{i:0;s:7:\"img.src\";i:1;s:14:\"div.data-thumb\";i:2;s:12:\"img.data-src\";i:3;s:20:\"div.data-large_image\";i:4;s:19:\"img.retina_logo_url\";i:5;s:23:\"div.data-parallax-image\";i:6;s:12:\"video.poster\";}','yes'),(1918,'litespeed.conf.img_optm-webp_replace_srcset','','yes'),(1919,'litespeed.conf.img_optm-jpg_quality','82','yes'),(1920,'litespeed.conf.crawler','','yes'),(1921,'litespeed.conf.crawler-inc_posts','1','yes'),(1922,'litespeed.conf.crawler-inc_pages','1','yes'),(1923,'litespeed.conf.crawler-inc_cats','1','yes'),(1924,'litespeed.conf.crawler-inc_tags','1','yes'),(1925,'litespeed.conf.crawler-exc_cpt','a:0:{}','yes'),(1926,'litespeed.conf.crawler-order_links','','yes'),(1927,'litespeed.conf.crawler-usleep','500','yes'),(1928,'litespeed.conf.crawler-run_duration','400','yes'),(1929,'litespeed.conf.crawler-run_interval','600','yes'),(1930,'litespeed.conf.crawler-crawl_interval','302400','yes'),(1931,'litespeed.conf.crawler-threads','3','yes'),(1932,'litespeed.conf.crawler-timeout','30','yes'),(1933,'litespeed.conf.crawler-load_limit','1','yes'),(1934,'litespeed.conf.crawler-sitemap','','yes'),(1935,'litespeed.conf.crawler-drop_domain','1','yes'),(1936,'litespeed.conf.crawler-map_timeout','120','yes'),(1937,'litespeed.conf.crawler-roles','a:0:{}','yes'),(1938,'litespeed.conf.crawler-cookies','a:0:{}','yes'),(1939,'litespeed.conf.misc-htaccess_front','','yes'),(1940,'litespeed.conf.misc-htaccess_back','','yes'),(1941,'litespeed.conf.misc-heartbeat_front','','yes'),(1942,'litespeed.conf.misc-heartbeat_front_ttl','60','yes'),(1943,'litespeed.conf.misc-heartbeat_back','','yes'),(1944,'litespeed.conf.misc-heartbeat_back_ttl','60','yes'),(1945,'litespeed.conf.misc-heartbeat_editor','','yes'),(1946,'litespeed.conf.misc-heartbeat_editor_ttl','15','yes'),(1947,'litespeed.conf.cdn','','yes'),(1948,'litespeed.conf.cdn-ori','a:0:{}','yes'),(1949,'litespeed.conf.cdn-ori_dir','a:2:{i:0;s:10:\"wp-content\";i:1;s:11:\"wp-includes\";}','yes'),(1950,'litespeed.conf.cdn-exc','a:0:{}','yes'),(1951,'litespeed.conf.cdn-remote_jq','','yes'),(1952,'litespeed.conf.cdn-quic','','yes'),(1953,'litespeed.conf.cdn-cloudflare','','yes'),(1954,'litespeed.conf.cdn-cloudflare_email','','yes'),(1955,'litespeed.conf.cdn-cloudflare_key','','yes'),(1956,'litespeed.conf.cdn-cloudflare_name','','yes'),(1957,'litespeed.conf.cdn-cloudflare_zone','','yes'),(1958,'litespeed.conf.cdn-mapping','a:1:{i:0;a:5:{s:3:\"url\";b:0;s:7:\"inc_img\";s:1:\"1\";s:7:\"inc_css\";s:1:\"1\";s:6:\"inc_js\";s:1:\"1\";s:8:\"filetype\";a:17:{i:0;s:4:\".aac\";i:1;s:4:\".css\";i:2;s:4:\".eot\";i:3;s:4:\".gif\";i:4;s:5:\".jpeg\";i:5;s:3:\".js\";i:6;s:4:\".jpg\";i:7;s:5:\".less\";i:8;s:4:\".mp3\";i:9;s:4:\".mp4\";i:10;s:4:\".ogg\";i:11;s:4:\".otf\";i:12;s:4:\".pdf\";i:13;s:4:\".png\";i:14;s:4:\".svg\";i:15;s:4:\".ttf\";i:16;s:5:\".woff\";}}}','yes'),(1959,'litespeed.conf.cdn-attr','a:5:{i:0;s:4:\".src\";i:1;s:9:\".data-src\";i:2;s:5:\".href\";i:3;s:7:\".poster\";i:4;s:13:\"source.srcset\";}','yes'),(1962,'litespeed.optimize.timestamp_purge_css','1604504205','yes'),(2496,'loginizer_version','1.6.5','yes'),(2497,'loginizer_options','a:0:{}','yes'),(2498,'loginizer_last_reset','1609921935','yes'),(2499,'loginizer_whitelist','a:0:{}','yes'),(2500,'loginizer_blacklist','a:0:{}','yes'),(2501,'loginizer_2fa_whitelist','a:0:{}','yes'),(2502,'loginizer_ins_time','1608165241','yes'),(2503,'loginizer_promo_time','1608165241','yes'),(2505,'_site_transient_update_core','O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:57:\"https://downloads.wordpress.org/release/wordpress-5.6.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:57:\"https://downloads.wordpress.org/release/wordpress-5.6.zip\";s:10:\"no_content\";s:68:\"https://downloads.wordpress.org/release/wordpress-5.6-no-content.zip\";s:11:\"new_bundled\";s:69:\"https://downloads.wordpress.org/release/wordpress-5.6-new-bundled.zip\";s:7:\"partial\";s:0:\"\";s:8:\"rollback\";s:0:\"\";}s:7:\"current\";s:3:\"5.6\";s:7:\"version\";s:3:\"5.6\";s:11:\"php_version\";s:6:\"5.6.20\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.6\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1609921936;s:15:\"version_checked\";s:3:\"5.6\";s:12:\"translations\";a:0:{}}','no'),(2495,'db_upgraded','','yes'),(2520,'_transient_health-check-site-status-result','{\"good\":15,\"recommended\":5,\"critical\":0}','yes'),(2586,'_site_transient_timeout_php_check_6a93f292d9a273c004fc36e1f86d97b3','1610087549','no'),(2587,'_site_transient_php_check_6a93f292d9a273c004fc36e1f86d97b3','a:5:{s:19:\"recommended_version\";s:3:\"7.4\";s:15:\"minimum_version\";s:6:\"5.6.20\";s:12:\"is_supported\";b:0;s:9:\"is_secure\";b:1;s:13:\"is_acceptable\";b:1;}','no'),(2638,'_site_transient_update_themes','O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1609921936;s:7:\"checked\";a:2:{s:15:\"twentyseventeen\";s:3:\"2.2\";s:12:\"twentytwenty\";s:3:\"1.6\";}s:8:\"response\";a:1:{s:15:\"twentyseventeen\";a:6:{s:5:\"theme\";s:15:\"twentyseventeen\";s:11:\"new_version\";s:3:\"2.5\";s:3:\"url\";s:45:\"https://wordpress.org/themes/twentyseventeen/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/theme/twentyseventeen.2.5.zip\";s:8:\"requires\";s:3:\"4.7\";s:12:\"requires_php\";s:5:\"5.2.4\";}}s:9:\"no_update\";a:1:{s:12:\"twentytwenty\";a:6:{s:5:\"theme\";s:12:\"twentytwenty\";s:11:\"new_version\";s:3:\"1.6\";s:3:\"url\";s:42:\"https://wordpress.org/themes/twentytwenty/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/theme/twentytwenty.1.6.zip\";s:8:\"requires\";s:3:\"4.7\";s:12:\"requires_php\";s:5:\"5.2.4\";}}s:12:\"translations\";a:0:{}}','no'),(2639,'_site_transient_update_plugins','O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1609921937;s:7:\"checked\";a:4:{s:19:\"akismet/akismet.php\";s:5:\"4.1.7\";s:9:\"hello.php\";s:5:\"1.7.2\";s:35:\"litespeed-cache/litespeed-cache.php\";s:5:\"3.4.2\";s:23:\"loginizer/loginizer.php\";s:5:\"1.6.5\";}s:8:\"response\";a:1:{s:35:\"litespeed-cache/litespeed-cache.php\";O:8:\"stdClass\":12:{s:2:\"id\";s:29:\"w.org/plugins/litespeed-cache\";s:4:\"slug\";s:15:\"litespeed-cache\";s:6:\"plugin\";s:35:\"litespeed-cache/litespeed-cache.php\";s:11:\"new_version\";s:5:\"3.6.1\";s:3:\"url\";s:46:\"https://wordpress.org/plugins/litespeed-cache/\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/plugin/litespeed-cache.3.6.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:68:\"https://ps.w.org/litespeed-cache/assets/icon-256x256.png?rev=1574145\";s:2:\"1x\";s:68:\"https://ps.w.org/litespeed-cache/assets/icon-128x128.png?rev=1574145\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:71:\"https://ps.w.org/litespeed-cache/assets/banner-1544x500.png?rev=2031698\";s:2:\"1x\";s:70:\"https://ps.w.org/litespeed-cache/assets/banner-772x250.png?rev=2031698\";}s:11:\"banners_rtl\";a:0:{}s:6:\"tested\";s:3:\"5.6\";s:12:\"requires_php\";b:0;s:13:\"compatibility\";O:8:\"stdClass\":0:{}}}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:3:{s:19:\"akismet/akismet.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:21:\"w.org/plugins/akismet\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:5:\"4.1.7\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/akismet.4.1.7.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:59:\"https://ps.w.org/akismet/assets/icon-256x256.png?rev=969272\";s:2:\"1x\";s:59:\"https://ps.w.org/akismet/assets/icon-128x128.png?rev=969272\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:61:\"https://ps.w.org/akismet/assets/banner-772x250.jpg?rev=479904\";}s:11:\"banners_rtl\";a:0:{}}s:9:\"hello.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:25:\"w.org/plugins/hello-dolly\";s:4:\"slug\";s:11:\"hello-dolly\";s:6:\"plugin\";s:9:\"hello.php\";s:11:\"new_version\";s:5:\"1.7.2\";s:3:\"url\";s:42:\"https://wordpress.org/plugins/hello-dolly/\";s:7:\"package\";s:60:\"https://downloads.wordpress.org/plugin/hello-dolly.1.7.2.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-256x256.jpg?rev=2052855\";s:2:\"1x\";s:64:\"https://ps.w.org/hello-dolly/assets/icon-128x128.jpg?rev=2052855\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:66:\"https://ps.w.org/hello-dolly/assets/banner-772x250.jpg?rev=2052855\";}s:11:\"banners_rtl\";a:0:{}}s:23:\"loginizer/loginizer.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:23:\"w.org/plugins/loginizer\";s:4:\"slug\";s:9:\"loginizer\";s:6:\"plugin\";s:23:\"loginizer/loginizer.php\";s:11:\"new_version\";s:5:\"1.6.5\";s:3:\"url\";s:40:\"https://wordpress.org/plugins/loginizer/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/plugin/loginizer.1.6.5.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:62:\"https://ps.w.org/loginizer/assets/icon-256x256.png?rev=1381093\";s:2:\"1x\";s:62:\"https://ps.w.org/loginizer/assets/icon-128x128.png?rev=1381093\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:65:\"https://ps.w.org/loginizer/assets/banner-1544x500.jpg?rev=1517954\";s:2:\"1x\";s:64:\"https://ps.w.org/loginizer/assets/banner-772x250.jpg?rev=1517954\";}s:11:\"banners_rtl\";a:0:{}}}}','no'),(2636,'_site_transient_timeout_theme_roots','1609923736','no'),(2637,'_site_transient_theme_roots','a:2:{s:15:\"twentyseventeen\";s:7:\"/themes\";s:12:\"twentytwenty\";s:7:\"/themes\";}','no');
/*!40000 ALTER TABLE `wpaa_options` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wpaa_postmeta`
--

DROP TABLE IF EXISTS `wpaa_postmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wpaa_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wpaa_postmeta`
--

LOCK TABLES `wpaa_postmeta` WRITE;
/*!40000 ALTER TABLE `wpaa_postmeta` DISABLE KEYS */;
INSERT INTO `wpaa_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES (1,2,'_wp_page_template','default'),(2,3,'_wp_page_template','default');
/*!40000 ALTER TABLE `wpaa_postmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wpaa_posts`
--

DROP TABLE IF EXISTS `wpaa_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wpaa_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT 0,
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(255) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT 0,
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wpaa_posts`
--

LOCK TABLES `wpaa_posts` WRITE;
/*!40000 ALTER TABLE `wpaa_posts` DISABLE KEYS */;
INSERT INTO `wpaa_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES (1,1,'2020-01-29 08:25:03','2020-01-29 08:25:03','<!-- wp:paragraph -->\n<p>Welcome to WordPress. This is your first post. Edit or delete it, then start writing!</p>\n<!-- /wp:paragraph -->','Hello world!','','publish','open','open','','hello-world','','','2020-01-29 08:25:03','2020-01-29 08:25:03','',0,'http://stagging.ebewelebrown.com/?p=1',0,'post','',1),(2,1,'2020-01-29 08:25:03','2020-01-29 08:25:03','<!-- wp:paragraph -->\n<p>This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...or something like this:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class=\"wp-block-quote\"><p>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>As a new WordPress user, you should go to <a href=\"http://stagging.ebewelebrown.com/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!</p>\n<!-- /wp:paragraph -->','Sample Page','','publish','closed','open','','sample-page','','','2020-01-29 08:25:03','2020-01-29 08:25:03','',0,'http://stagging.ebewelebrown.com/?page_id=2',0,'page','',0),(3,1,'2020-01-29 08:25:03','2020-01-29 08:25:03','<!-- wp:heading --><h2>Who we are</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Our website address is: http://stagging.ebewelebrown.com.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What personal data we collect and why we collect it</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Comments</h3><!-- /wp:heading --><!-- wp:paragraph --><p>When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor&#8217;s IP address and browser user agent string to help spam detection.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>An anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Media</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Contact forms</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Cookies</h3><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you visit our login page, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>When you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select &quot;Remember Me&quot;, your login will persist for two weeks. If you log out of your account, the login cookies will be removed.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>If you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Embedded content from other websites</h3><!-- /wp:heading --><!-- wp:paragraph --><p>Articles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.</p><!-- /wp:paragraph --><!-- wp:heading {\"level\":3} --><h3>Analytics</h3><!-- /wp:heading --><!-- wp:heading --><h2>Who we share your data with</h2><!-- /wp:heading --><!-- wp:heading --><h2>How long we retain your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>For users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>What rights you have over your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>If you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Where we send your data</h2><!-- /wp:heading --><!-- wp:paragraph --><p>Visitor comments may be checked through an automated spam detection service.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Your contact information</h2><!-- /wp:heading --><!-- wp:heading --><h2>Additional information</h2><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>How we protect your data</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>What data breach procedures we have in place</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>What third parties we receive data from</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>What automated decision making and/or profiling we do with user data</h3><!-- /wp:heading --><!-- wp:heading {\"level\":3} --><h3>Industry regulatory disclosure requirements</h3><!-- /wp:heading -->','Privacy Policy','','draft','closed','open','','privacy-policy','','','2020-01-29 08:25:03','2020-01-29 08:25:03','',0,'http://stagging.ebewelebrown.com/?page_id=3',0,'page','',0);
/*!40000 ALTER TABLE `wpaa_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wpaa_term_relationships`
--

DROP TABLE IF EXISTS `wpaa_term_relationships`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wpaa_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wpaa_term_relationships`
--

LOCK TABLES `wpaa_term_relationships` WRITE;
/*!40000 ALTER TABLE `wpaa_term_relationships` DISABLE KEYS */;
INSERT INTO `wpaa_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES (1,1,0);
/*!40000 ALTER TABLE `wpaa_term_relationships` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wpaa_term_taxonomy`
--

DROP TABLE IF EXISTS `wpaa_term_taxonomy`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wpaa_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wpaa_term_taxonomy`
--

LOCK TABLES `wpaa_term_taxonomy` WRITE;
/*!40000 ALTER TABLE `wpaa_term_taxonomy` DISABLE KEYS */;
INSERT INTO `wpaa_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES (1,1,'category','',0,1);
/*!40000 ALTER TABLE `wpaa_term_taxonomy` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wpaa_termmeta`
--

DROP TABLE IF EXISTS `wpaa_termmeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wpaa_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wpaa_termmeta`
--

LOCK TABLES `wpaa_termmeta` WRITE;
/*!40000 ALTER TABLE `wpaa_termmeta` DISABLE KEYS */;
/*!40000 ALTER TABLE `wpaa_termmeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wpaa_terms`
--

DROP TABLE IF EXISTS `wpaa_terms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wpaa_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wpaa_terms`
--

LOCK TABLES `wpaa_terms` WRITE;
/*!40000 ALTER TABLE `wpaa_terms` DISABLE KEYS */;
INSERT INTO `wpaa_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES (1,'Uncategorized','uncategorized',0);
/*!40000 ALTER TABLE `wpaa_terms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wpaa_usermeta`
--

DROP TABLE IF EXISTS `wpaa_usermeta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wpaa_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wpaa_usermeta`
--

LOCK TABLES `wpaa_usermeta` WRITE;
/*!40000 ALTER TABLE `wpaa_usermeta` DISABLE KEYS */;
INSERT INTO `wpaa_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES (1,1,'nickname','Tommy'),(2,1,'first_name',''),(3,1,'last_name',''),(4,1,'description',''),(5,1,'rich_editing','true'),(6,1,'syntax_highlighting','true'),(7,1,'comment_shortcuts','false'),(8,1,'admin_color','fresh'),(9,1,'use_ssl','0'),(10,1,'show_admin_bar_front','true'),(11,1,'locale',''),(12,1,'wpaa_capabilities','a:1:{s:13:\"administrator\";b:1;}'),(13,1,'wpaa_user_level','10'),(14,1,'dismissed_wp_pointers',''),(15,1,'show_welcome_panel','1'),(16,1,'session_tokens','a:1:{s:64:\"b46105e130698d52f314369857f0a034d14883cb33bcf07936f1ae9e75e67e2a\";a:4:{s:10:\"expiration\";i:1581007489;s:2:\"ip\";s:15:\"160.119.125.188\";s:2:\"ua\";s:115:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.130 Safari/537.36\";s:5:\"login\";i:1580834689;}}'),(17,1,'wpaa_dashboard_quick_press_last_post_id','4'),(18,1,'community-events-location','a:1:{s:2:\"ip\";s:13:\"160.119.125.0\";}');
/*!40000 ALTER TABLE `wpaa_usermeta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `wpaa_users`
--

DROP TABLE IF EXISTS `wpaa_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `wpaa_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(255) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT 0,
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `wpaa_users`
--

LOCK TABLES `wpaa_users` WRITE;
/*!40000 ALTER TABLE `wpaa_users` DISABLE KEYS */;
INSERT INTO `wpaa_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES (1,'Tommy','$P$BvGdm4XSETlXa9D7MtR/2MxRvUIoEy/','Tommy','tommyriode@gmail.com','','2020-01-29 08:25:03','',0,'Tommy');
/*!40000 ALTER TABLE `wpaa_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'ebewmyqz_wp605'
--

--
-- Dumping routines for database 'ebewmyqz_wp605'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-01-07  3:03:21
